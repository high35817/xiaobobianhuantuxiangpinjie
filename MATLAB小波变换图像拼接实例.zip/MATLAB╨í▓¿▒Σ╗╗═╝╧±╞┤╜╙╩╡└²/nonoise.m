function x=nonoise(f,m,th)
e=1/(2^(1/2));
Ld=e*[1,1]';
Hd=e*[-1,1]';
for i=1:m 
    if i<m
        c1(i)=[f(i),f(i+1)]*Ld;
    else
        c1(i)=[f(i),f(1)]*Ld;
    end
end
c1j=c1(:,1:2:m);
for i=1:m
    if i<m
        d1(i)=[f(i),f(i+1)]*Hd;
    else
        d1(i)=[f(i),f(1)]*Hd;
    end
end
d1j=d1(:,1:2:m);
[m1,n1]=size(c1j);
for i=1:n1
    if(abs(d1j(i))<th)
        d1j(i)=0;
    end

end
j=1;
for i=1:2*n1
    if mod(i,2)==1
        c(i)=c1j(j);
        d(i)=d1j(j);
        j=j+1;
    else
        c(i)=0;
        d(i)=0;
    end
end
[m1,n1]=size(c);
for i=1:n1
    if i<n1
        lc(i)=[c(i),c(i+1)]*Ld;
    else
        lc(i)=[c(i),c(1)]*Ld;
    end
end
Hd=e*[1,-1]';
for i=1:n1
    if i<n1
        dc(i)=[d(i),d(i+1)]*Hd;
    else
        dc(i)=[d(i),d(1)]*Hd;
    end
end   
xl=lc+dc;

for i=1:n1
    if(i>1)
        x(i)=xl(i-1);
    else
        x(i)=xl(n1);
    end
end
        
